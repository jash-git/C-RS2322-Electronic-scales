﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Ports;              // for SerialPort class

namespace ReadDemo_Console
{
    class Program
    {
        private SerialPort _serialPort;

        static void Main(string[] args)
        {
            new Program();            
        }

        private Program()
        {
            // Set up serial port
            _serialPort = new SerialPort("COM5", 9600, Parity.None, 8, StopBits.One);

            // Set DataReceived Event Handler
            _serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            try
            {
                // Open serial port
                _serialPort.Open();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Open() error: " + ex.Message);
            }

            // Read from the console, to stop it from closing.
            Console.Read();
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            Console.WriteLine(_serialPort.ReadLine());
        }
    }
}
