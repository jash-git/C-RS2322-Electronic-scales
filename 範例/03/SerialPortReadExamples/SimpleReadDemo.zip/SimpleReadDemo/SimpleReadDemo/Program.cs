﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Ports;              // for SerialPort class

namespace SimpleReadDemo
{
    class Program
    {
        

        static void Main(string[] args)
        {
            // Set up serial port
            SerialPort _serialPort = new SerialPort("COM5", 9600, Parity.None, 8, StopBits.One);

            try
            {
                // Open serial port
                _serialPort.Open();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Open() error: " + ex.Message);
            }

            // Read serial port and print to console
            while (true)
            {
                string dataLine = _serialPort.ReadLine();
                Console.WriteLine(dataLine);
            }            
        }
    }
}
